'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/Zippojones007/ZMC.github.io/refs/heads/main/Wizardprojects/Darealist/Darealistbuilds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/Zippojones007/ZMC.github.io/refs/heads/main/Wizardprojects/Darealist/darealistnotify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
