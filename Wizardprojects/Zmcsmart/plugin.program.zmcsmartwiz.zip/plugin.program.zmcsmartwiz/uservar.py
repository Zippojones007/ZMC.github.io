import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/Zippojones007/ZMC.github.io/main/Wizardprojects/Zmcsmart/zmcbuilds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/Zippojones007/ZMC.github.io/main/Wizardprojects/Zmcsmart/zmcnotify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
